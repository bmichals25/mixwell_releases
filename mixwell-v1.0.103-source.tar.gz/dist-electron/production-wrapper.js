// Production wrapper that mimics the development mode approach
"use strict";
require("./index-DP5_wdC0.js");
require("electron");
require("node:zlib");
require("node:os");
require("node:path");
require("node:http");
require("node:url");
require("node:fs");
require("node:fs/promises");
require("node:child_process");